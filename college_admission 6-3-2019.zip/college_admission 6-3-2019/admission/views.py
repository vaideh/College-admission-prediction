from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection 
# from admission.models import busr,booking 
from django.http import HttpResponse 
from django.template import Context 
from django.template.loader import get_template 
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
#from bus.forms import LoginForm
from django.core.mail import send_mail
from django.core.mail import EmailMessage

# Create your views here.
def reginsert(request):
	college_Name=request.GET['college_name'] 
	Address=request.GET['address']
	City=request.GET['city'] 
	Zipcode=request.GET['zipcode']
	contact_number=request.GET['cnumber']
	Email=request.GET['email']
	Total_seat=request.GET['total_seat']
	website=request.GET['website']
	Password=request.GET['pwd']
	Retype_password=request.GET['password']
	cursor=connection.cursor()
	sql4="insert into tbl_clgregister(college_name,address,city,zipcode,cnumber,email,total_seat,website,pwd,password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(college_Name,Address,City,Zipcode,contact_number,Email,Total_seat,website,Password,Retype_password)  
	cursor.execute(sql4)
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	return HttpResponse(html)
	return  render(request ,'newlogin.html')

	
def studinsert(request):
	First_name=request.GET['first_name'] 
	Second_name=request.GET['second_name']
	Address=request.GET['address']
	Gender=request.GET['gender'] 
	DOB=request.GET['dob']
	contact_number=request.GET['cnumber']
	Email=request.GET['email']
	Password=request.GET['pwd']
	Retype_password=request.GET['password']
	cursor=connection.cursor()
	sql4="insert into tbl_studregister(first_name,second_name,address,gender,dob,cnumber,email,pwd,password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(First_name,Second_name,Address,Gender,DOB,contact_number,Email,Password,Retype_password)  
	cursor.execute(sql4)
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	return HttpResponse(html)
	return  render(request ,'newlogin.html')	