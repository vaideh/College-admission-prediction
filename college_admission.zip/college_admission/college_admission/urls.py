"""college_admission URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import  include, url,patterns
from admission.views import *
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
admin.autodiscover()

urlpatterns = [
    
	url(r'^$',TemplateView.as_view(template_name = 'index.html')),
	url(r'^home/',TemplateView.as_view(template_name = 'index.html')),
	url(r'^login/',TemplateView.as_view(template_name = 'login.html')),
	url(r'^searchlogin/',searchlogin,name='searchlogin'),
	url(r'^log/',TemplateView.as_view(template_name = 'login.html')),
	url(r'^adminregistration/',TemplateView.as_view(template_name = 'admin.html')),
	url(r'^insertadmin/',insertadmin,name='insertadmin'),
	url(r'^adminreg/',TemplateView.as_view(template_name = 'admin.html')),
	url(r'^registration/',TemplateView.as_view(template_name = 'collegereg.html')),
	url(r'^reginsert/',reginsert,name='reginsert'),
	url(r'^college/',TemplateView.as_view(template_name = 'collegereg.html')),
	url(r'^studregistration/',TemplateView.as_view(template_name = 'studentreg.html')),
	url(r'^studinsert/',studinsert,name='studinsert'),
	url(r'^stud/',TemplateView.as_view(template_name = 'studentreg.html')),
	url(r'^homeadmin/',TemplateView.as_view(template_name = 'adminhomepage.html')),
	url(r'^homeclg/',TemplateView.as_view(template_name = 'clghomepage.html')),
	url(r'^homestud/',TemplateView.as_view(template_name = 'studhomepage.html')),
    url(r'^courseregistration/',TemplateView.as_view(template_name = 'addcourse.html')),
	url(r'^addcourse/',addcourse,name='addcourse'),
	url(r'^course/',course,name='course'),
	#url(r'^addcourse/',TemplateView.as_view(template_name = 'addcourse.html')),
	#url(r'^prediction/',TemplateView.as_view(template_name = 'predict.html')),
	#url(r'^predict/',predict,name='predict'),
	#url(r'^qualific/',TemplateView.as_view(template_name = 'addqualification.html')),
	url(r'^qualification/',qualification,name='qualification'),
	url(r'^qua/',TemplateView.as_view(template_name = 'addqualification.html')),
	url(r'^quali/',quali,name='quali'),
	#url(r'^viewingclg/',TemplateView.as_view(template_name = 'viewclg.html')),
	url(r'^viewclg/',viewclg,name='viewclg'),
	#url(r'^clgview/',TemplateView.as_view(template_name = 'viewclg.html')),
	url(r'^viewstud/',viewstud,name='viewstud'),
	url(r'^viewprofile/',viewprofile,name='viewprofile'),
	url(r'^viewcourse/',viewcourse,name='viewcourse'),
	url(r'^viewstudprofile/',viewstudprofile,name='viewstudprofile'),
	url(r'^viewquali/',viewquali,name='viewquali'),
	
	
	
    
]
