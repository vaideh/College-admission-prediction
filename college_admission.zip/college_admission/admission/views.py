from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection 
# from admission.models import busr,booking 
from django.http import HttpResponse 
from django.template import Context 
from django.template.loader import get_template 
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
#from bus.forms import LoginForm
from django.core.mail import send_mail
from django.core.mail import EmailMessage

# Create your views here.

def searchlogin(request):
	cursor=connection.cursor()
	p=request.GET['username']
	q=request.GET['password']
	sql2="select * from tbl_login where username='%s' and password='%s' and status='true'" %(p,q)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if  (cursor.rowcount) > 0:
		sql3 = "select * from tbl_login  where username='%s' and password='%s'" % (p, q)
		cursor.execute(sql3)
		result1 = cursor.fetchall()
		for row1 in result1:
			d = row1[0]
			x=row1[3]
		request.session['u_id'] = d
		request.session['user_type'] =x
		if(x=='admin'):
			return render(request ,'adminhomepage.html') 
		elif(x=='college'):
			return render(request,'clghomepage.html')
		elif(x=='student'):
			return render(request,'studhomepage.html')
	else:
		html="<script>alert('invalid password and username ');window.location='/login/';</script>"
		return HttpResponse(html)
def logout(request):
	try:
		del request.session['u_id']
		del request.session['user_type']
	except:
		pass
	return HttpResponse("<script>alert('you are loged out');window.location='/login/';</script>")
	
def insertadmin(request):
	id=0
	Name=request.GET['admin_name'] 
	Country=request.GET['country']
	State=request.GET['state']
	Phone=request.GET['phone']
	Mobile=request.GET['mobile']
	Email_id=request.GET['email_id']
	Password=request.GET['password']
	Retype_Password=request.GET['re_password']
	cursor=connection.cursor()
	sql4="insert into tbl_admin(name,country,state,phone,mobile,email,password,re_password) values('%s','%s','%s','%s','%s','%s','%s','%s')"%(Name,Country,State,Phone,Mobile,Email_id,Password,Retype_Password)  
	cursor.execute(sql4)
	sqlad="select max(admin_id) from tbl_admin"
	result=cursor.fetchall()
	for row in result: 
		id=int(row[0])
	sql="insert into tbl_login(u_id,username,password,user_type,status)values('%s','%s','%s','%s')"%(Email_id,Password,'admin','false')
	cursor.execute(sql)
	html="<script>alert('successfully registered! ');window.location='/l/';</script>"
	return HttpResponse(html)	

def reginsert(request):
	college_Name=request.GET['college_name'] 
	Address=request.GET['address']
	City=request.GET['city'] 
	Zipcode=request.GET['zipcode']
	contact_number=request.GET['cnumber']
	Email=request.GET['email']
	Total_seat=request.GET['total_seat']
	website=request.GET['website']
	Password=request.GET['pwd']
	Retype_password=request.GET['password']
	cursor=connection.cursor()
	sql2="select * from tbl_login where username='%s'" %(Email)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('already registerd');window.location='/registration/';</script>"
	else:
		sql4="insert into tbl_clgregister(college_name,address,city,zipcode,cnumber,email,total_seat,website,pwd,password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(college_Name,Address,City,Zipcode,contact_number,Email,Total_seat,website,Password,Retype_password)  
		cursor.execute(sql4)
		sql3="select max(clg_id) as id from tbl_clgregister" 
		cursor.execute(sql3)
		result=cursor.fetchall()
		for row in result:
			id=row[0]
		sql="insert into tbl_login(u_id,username,password,user_type,status)values('%d','%s','%s','%s','%s')"%(id,Email,Password,'college','false')
		cursor.execute(sql)
		html="<script>alert('successfully registered! ');window.location='/login/';</script>"
	return HttpResponse(html)

def studinsert(request):
	First_name=request.GET['first_name'] 
	Second_name=request.GET['second_name']
	Address=request.GET['address']
	Gender=request.GET['gender'] 
	DOB=request.GET['dob']
	contact_number=request.GET['cnumber']
	Email=request.GET['email']
	Password=request.GET['pwd']
	Retype_password=request.GET['password']
	cursor=connection.cursor()
	sql4="insert into tbl_studregister(first_name,second_name,address,gender,dob,cnumber,email,pwd,password) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(First_name,Second_name,Address,Gender,DOB,contact_number,Email,Password,Retype_password)  
	cursor.execute(sql4)
	sql3="select max(stud_id) as id from tbl_studregister" 
	cursor.execute(sql3)
	result=cursor.fetchall()
	for row in result:
			id=row[0]
	sql="insert into tbl_login(u_id,username,password,user_type,status)values('%d','%s','%s','%s','%s')"%(id,Email,Password,'student','true')
	cursor.execute(sql)
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	return HttpResponse(html)
	return  render(request ,'newlogin.html')
def course(request):
	return  render(request ,'addcourse.html')
def addcourse(request):
	Course=request.GET['course'] 
	Stream=request.GET['stream']
	Duration=request.GET['duration']
	Semester=request.GET['semester'] 
	Total_seat=request.GET['total_seat']
	clg_id=request.session['u_id']
	cursor=connection.cursor()
	sql4="insert into tbl_course(course,stream,duration,semester,total_seat,clg_id) values('%s','%s','%s','%s','%s','%s')"%(Course,Stream,Duration,Semester,Total_seat,clg_id)  
	cursor.execute(sql4)
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	return HttpResponse(html)
	return  render(request ,'newlogin.html')
	
#--------------------------------------------------------student add qualification--------------------------------------------------------------------------------		
def quali(request):
	return  render(request ,'addqualification.html')	
def qualification(request):
	Mark1=request.GET['mark1']
	School1=request.GET['school1']
	Board1=request.GET['board1']
	Year_of_passing1=request.GET['year1']
	Plustwo_mark=request.GET['mark2']
	School=request.GET['school2']
	Board=request.GET['board2']
	Year_of_passing=request.GET['year2']
	jee_score=request.GET['score']
	stud_id=request.session['u_id']
	cursor=connection.cursor()
	sql4="insert into tbl_quali(sslc_mark,school1,board1,year1,plustwo_mark,school2,board2,year2,jee_score,stud_id) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(Mark1,School1,Board1,Year_of_passing1,Plustwo_mark,School,Board,Year_of_passing,jee_score,stud_id)  
	cursor.execute(sql4)
	html="<script>alert('successfully registered! ');window.location='/newlogin/';</script>"
	return HttpResponse(html)
	return  render(request ,'newlogin.html')
#---------------------------------------------------------admin view college------------------------------------------------------------------------------------------
def viewclg(request):
	# template = get_template('detailes.html')
	clg_id=request.session['u_id']
	cursor = connection.cursor()
	list=[]
	sql="select * from tbl_studregister "
	cursor.execute(sql)
	result = cursor.fetchall()
	for row in result:
		w = {'clg_id' : row[0],'college_name': row[1],'address':row[2],'city':row[3],'zipcode': row[4],'cnumber': row[5],'email': row[6],'total_seat': row[7],'website': row[8]}
		list.append(w)
	return render(request,'viewclg.html', {'list': list})
#------------------------------------------------admin view student -----------------------------------------------------------------------------------------
def viewstud(request):
	# template = get_template('detailes.html')
	clg_id=request.session['u_id']
	cursor = connection.cursor()
	list=[]
	sql="select * from tbl_studregister  "
	cursor.execute(sql)
	result = cursor.fetchall()
	for row in result:
		w = {'stud_id' : row[0],'first_name': row[1],'second_name':row[2],'address':row[3],'gender': row[4],'dob': row[5],'cnumber': row[6],'email': row[7]}
		list.append(w)
	return render(request,'viewstud.html', {'list': list})
#------------------------------------------------ clg view profile --------------------------------------------------------------------------------------------------	
def viewprofile(request):
	clg_id=request.session['u_id']
	cursor=connection.cursor()
	sql="select * from tbl_login where user_type='college' and u_id='%s' and status='true'"%(request.session['u_id'])
	list=[]
	cursor.execute(sql)
	result1=cursor.fetchall()
	for row1 in result1:
		sql1="select * from tbl_clgregister where clg_id='%s'"%(row1[0])
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row in result:
			w = {'college_name': row[1],'address':row[2],'city':row[3],'zipcode': row[4],'cnumber': row[5],'email': row[6],'total_seat': row[7],'website': row[8]}
			list.append(w)
	return render(request,'viewprofile.html', {'list': list})
#-------------------------------------------clg view course------------------------------------------------------------------------------------------------------------	
def viewcourse(request):
	clg_id=request.session['u_id']
	cursor=connection.cursor()
	#sql="select * from tbl_login where user_type='college' and u_id='%s' and status='true'"%(request.session['u_id'])
	list=[]
	#cursor.execute(sql)
	#result1=cursor.fetchall()
	#for row1 in result1:
	sql1="select * from tbl_course where clg_id='%s'"%(request.session['u_id'])
	cursor.execute(sql1)
	result=cursor.fetchall()
	for row in result:
		w = {'course': row[1],'stream':row[2],'duration':row[3],'semester': row[4],'total_seat': row[5]}
		list.append(w)
	return render(request,'viewcourse.html', {'list': list})
	
#-----------------------------------------------view stud profile----------------------------------------------------------------------------
def viewstudprofile(request):
	clg_id=request.session['u_id']
	cursor=connection.cursor()
	sql="select * from tbl_login where user_type='student' and u_id='%s' and status='true'"%(request.session['u_id'])
	list=[]
	cursor.execute(sql)
	result1=cursor.fetchall()
	for row1 in result1:
		sql1="select * from tbl_studregister where stud_id='%s'"%(row1[0])
		cursor.execute(sql1)
		result=cursor.fetchall()
		for row in result:
			w = {'first_name': row[1],'second_name':row[2],'address':row[3],'gender': row[4],'dob': row[5],'cnumber': row[6],'email': row[7]}
			list.append(w)
	return render(request,'viewstudprofile.html', {'list': list}) 
	
def viewquali(request):
	clg_id=request.session['u_id']
	cursor=connection.cursor()
	#sql="select * from tbl_login where user_type='college' and u_id='%s' and status='true'"%(request.session['u_id'])
	list=[]
	#cursor.execute(sql)
	#result1=cursor.fetchall()
	#for row1 in result1:
	sql1="select * from tbl_quali where stud_id='%s'"%(request.session['u_id'])
	cursor.execute(sql1)
	result=cursor.fetchall()
	for row in result:
		w = {'sslc_mark': row[1],'school1':row[2],'board1':row[3],'year1': row[4],'plustwo_mark': row[5],'school2': row[6],'board2': row[7],'year2': row[8],'jee_score': row[9]}
		list.append(w)
	return render(request,'viewquali.html', {'list': list})